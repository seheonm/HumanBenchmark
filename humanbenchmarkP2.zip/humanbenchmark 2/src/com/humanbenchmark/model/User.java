package com.humanbenchmark.model;

public class User {
    private String name;
    private long reactionTime, sequenceMemory, aimTrainer, chimpTest, visualMemory, typing, numberMemory, verbalMemory;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getReactionTime() {
        return reactionTime;
    }

    public void setReactionTime(long reactionTime) {
        this.reactionTime = reactionTime;
    }

    public long getSequenceMemory() {
        return sequenceMemory;
    }

    public void setSequenceMemory(long sequenceMemory) {
        this.sequenceMemory = sequenceMemory;
    }

    public long getAimTrainer() {
        return aimTrainer;
    }

    public void setAimTrainer(long aimTrainer) {
        this.aimTrainer = aimTrainer;
    }

    public long getChimpTest() {
        return chimpTest;
    }

    public void setChimpTest(long chimpTest) {
        this.chimpTest = chimpTest;
    }

    public long getVisualMemory() {
        return visualMemory;
    }

    public void setVisualMemory(long visualMemory) {
        this.visualMemory = visualMemory;
    }

    public long getTyping() {
        return typing;
    }

    public void setTyping(long typing) {
        this.typing = typing;
    }

    public long getNumberMemory() {
        return numberMemory;
    }

    public void setNumberMemory(long numberMemory) {
        this.numberMemory = numberMemory;
    }

    public long getVerbalMemory() {
        return verbalMemory;
    }

    public void setVerbalMemory(long verbalMemory) {
        this.verbalMemory = verbalMemory;
    }

    @Override
    public String toString() {
        return name + "," + reactionTime + "," + sequenceMemory + "," + aimTrainer +  "," + chimpTest +  "," + visualMemory +
                "," + typing +    "," + numberMemory +  "," + verbalMemory;
    }
}
