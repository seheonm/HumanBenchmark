package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class TypingGame {
    private final Controller controller;
    private final Stage primaryStage;
    private final int currentState = 1;

    public TypingGame(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller = controller;
        showTypingGameScreen();
    }

    private void showTypingGameScreen() {
        BorderPane root= new BorderPane();
        Button backBtn = new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new HomeScreen(controller, primaryStage);
            }
        });
        GridPane gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        HBox topBox = new HBox();
        topBox.setSpacing(60);
        topBox.getChildren().addAll(backBtn);
        SimpleLongProperty time=new SimpleLongProperty();
        HBox bottomBtnBox = new HBox();
        Button saveScoreBtn = new Button("Save Score");
        saveScoreBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                controller.updateTypingTime(time.get());
                new TypingGame(TypingGame.this.controller, primaryStage);
            }
        });
        Button tryAgainBtn = new Button("Try Again");

        tryAgainBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new TypingGame(TypingGame.this.controller, primaryStage);
            }
        });
        bottomBtnBox.getChildren().addAll(saveScoreBtn, tryAgainBtn);
        bottomBtnBox.setVisible(false);
        TextArea a1= new TextArea();
        a1.setEditable(false);
        a1.setText("A paragraph is a self-contained unit of discourse in writing dealing with a particular point or idea. A paragraph consists of one or more sentences. Though not required by the syntax of any language, paragraphs are usually an expected part of formal writing, used to organize longer prose.");
        a1.setWrapText(true);
        TextArea a2= new TextArea();
        SimpleBooleanProperty isTyping = new SimpleBooleanProperty();

        isTyping.set(false);
        a2.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(final ObservableValue<? extends String> observable, final String oldValue, final String newValue) {
                if(!isTyping.get()){
                    isTyping.setValue(true);
                    time.set(System.currentTimeMillis());
                }
                if(a1.getText().equals(a2.getText())){
                    long end=System.currentTimeMillis();
                    time.set(end-time.get());
                    gridPane.getChildren().clear();
                    Label label = new Label("You have taken "+time.get()+" ms.");
                    label.setFont(Font.font(24));
                    label.setBackground(new Background(new BackgroundFill(Color.WHITE,
                            CornerRadii.EMPTY,
                            Insets.EMPTY)));
                    label.setAlignment(Pos.CENTER);
                    gridPane.add(label,1,1);
                    bottomBtnBox.setVisible(true);
                }
            }
        });
        gridPane.add(a1,0,0);
        gridPane.add(a2,0,1);

        root.setTop(topBox);
        Insets insets = new Insets(20);
        root.setPadding(insets);
        root.setCenter(gridPane);
        root.setBottom(bottomBtnBox);
      primaryStage.setScene(new Scene(root, 400, 300));


    }
}
