package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Random;

public class NumberMemoryGame {
    private final Controller controller;
    private final Stage primaryStage;
    private final int currentState = 1;

    public NumberMemoryGame(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller = controller;
        showNumberMemoryGameScreen();
    }

    private void showNumberMemoryGameScreen() {
        BorderPane root = new BorderPane();
        Button backBtn = new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new HomeScreen(controller, primaryStage);
            }
        });

        HBox topBox = new HBox();
        topBox.setSpacing(60);
        topBox.getChildren().addAll(backBtn);
        SimpleIntegerProperty level = new SimpleIntegerProperty();
        level.set(1);


        HBox bottomBtnBox = new HBox();
        Button saveScoreBtn = new Button("Save Score");
        saveScoreBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                controller.updateNumberMemoryScore(level.get());
                new NumberMemoryGame(NumberMemoryGame.this.controller, primaryStage);
            }
        });
        Button tryAgainBtn = new Button("Try Again");

        tryAgainBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new NumberMemoryGame(NumberMemoryGame.this.controller, primaryStage);
            }
        });
        bottomBtnBox.getChildren().addAll(saveScoreBtn, tryAgainBtn);
        bottomBtnBox.setVisible(false);

        GridPane gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        addLabel(gridPane, level, bottomBtnBox);


        root.setTop(topBox);
        Insets insets = new Insets(20);
        root.setPadding(insets);
        root.setCenter(gridPane);
        root.setBottom(bottomBtnBox);
        primaryStage.setScene(new Scene(root, 400, 300));
    }

    private void addLabel(GridPane gridPane, SimpleIntegerProperty level, HBox bottomBtnBox) {
        gridPane.getChildren().clear();
        SimpleLongProperty num = new SimpleLongProperty();
        final KeyFrame kf1 = new KeyFrame(Duration.millis(0), e -> {
            Random r = new Random();
            long l = level.get();
            if (l == 1) {
                num.set(r.nextInt(9) + 1);
            } else if (l == 2) {
                num.set(r.nextInt(99) + 10);
            } else if (l == 3) {
                num.set(r.nextInt(999) + 100);
            } else if (l == 4) {
                num.set(r.nextInt(9999) + 1000);
            } else if (l == 5) {
                num.set(r.nextInt(99999) + 10000);
            } else if (l == 6) {
                num.set(r.nextInt(999999) + 100000);
            } else if (l == 7) {
                num.set(r.nextInt(9999999) + 100000);
            }
            Label label = new Label(""+num.get());
            label.setFont(Font.font(24));
            label.setAlignment(Pos.CENTER);
            gridPane.add(label, 3, 4);
        });

        final KeyFrame kf2 = new KeyFrame(Duration.millis(2000), e -> {
            VBox vbox = new VBox();
            vbox.setSpacing(20);
            Label label = new Label("What was the number?");
            TextField field = new TextField();
            Button btn = new Button("Submit");
            vbox.getChildren().addAll(label,field,btn);
            gridPane.getChildren().clear();
            gridPane.add(vbox, 1, 0);
            btn.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    String text = field.getText();
                    if (null != text && !text.trim().isEmpty()) {
                        try {
                            long number = Long.parseLong(field.getText().trim());
                            if (number == num.get()) {
                                VBox vbox = new VBox();
                                vbox.setSpacing(20);
                                Label l1 = new Label("Number");
                                Label l2 = new Label("" + num.get());
                                Label l3 = new Label("Your Number");
                                Label l4 = new Label("" + number);
                                Label l5 = new Label("Level " + level.get());
                                l5.setFont(Font.font(24));
                                Button button =new Button();
                                button.setText("Next");
                                button.setOnAction(new EventHandler<ActionEvent>() {
                                    @Override
                                    public void handle(ActionEvent event) {
                                        level.set(level.get()+1);
                                        addLabel(gridPane, level, bottomBtnBox);
                                    }
                                });
                                gridPane.getChildren().clear();
                                vbox.getChildren().addAll(l1,l2,l3,l4,l5,button);
                                gridPane.add(vbox,3,0);
                            } else {
                                bottomBtnBox.setVisible(true);
                            }
                        } catch (NumberFormatException nfe) {

                        }

                    }

                }
            });
        });

        final Timeline timeline = new Timeline(kf1, kf2);
        Platform.runLater(timeline::play);

    }
}
