package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ReactionTimerGame {
    private final Controller controller;
    private final Stage primaryStage;
    private int currentState = 1;

    public ReactionTimerGame(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller = controller;
        showReactionTimerGameScreen();
    }

    private void showReactionTimerGameScreen() {
        primaryStage.setTitle("Reaction Timer Game");
        BorderPane  root = new BorderPane();

        HBox hBox = new HBox();
        hBox.setPrefWidth(this.primaryStage.getWidth());
        SimpleStringProperty text = new SimpleStringProperty();
        SimpleLongProperty start = new SimpleLongProperty();
        SimpleIntegerProperty counter = new SimpleIntegerProperty();
        SimpleLongProperty score = new SimpleLongProperty();


        text.set("Reaction Time Test");
        Label label = new Label();
        label.setPrefWidth(this.primaryStage.getWidth());
        label.setFont(Font.font(34));
        label.setAlignment(Pos.CENTER);
        label.textProperty().bind(text);
        hBox.getChildren().add(label);
        label.setTextFill(Color.WHITE);
        hBox.setBackground(new Background(new BackgroundFill(Color.BLUE,
                CornerRadii.EMPTY,
                Insets.EMPTY)));
        Button backBtn = new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new HomeScreen(controller,primaryStage);
            }
        });
        Label  userNameLabel = new Label(controller.getUserName());
        HBox topBox= new HBox();
        topBox.setSpacing(20);
        topBox.getChildren().addAll(backBtn,userNameLabel);

        Button saveScoreBtn = new Button("Save Score");
        saveScoreBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ReactionTimerGame.this.controller.updateReactionTime(score.get());
                new ReactionTimerGame(ReactionTimerGame.this.controller,primaryStage);
            }
        });
        Button  tryAgainBtn = new Button("Try Again");
        tryAgainBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new ReactionTimerGame(ReactionTimerGame.this.controller,primaryStage);
            }
        });
        HBox bottomBtnBox= new HBox();
        bottomBtnBox.getChildren().addAll(saveScoreBtn,tryAgainBtn);
        bottomBtnBox.setVisible(false);


        root.setTop(topBox);
        Insets insets = new Insets(10);
        root.setPadding(insets);
        root.setCenter(hBox);
        root.setBottom(bottomBtnBox);

        hBox.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                if (currentState == 1) {
                    final KeyFrame kf1 = new KeyFrame(Duration.millis(0), e -> {
                        text.set("Reaction Time Test");
                        hBox.setBackground(new Background(new BackgroundFill(Color.BLUE,
                            CornerRadii.EMPTY,
                            Insets.EMPTY)));});
                    final KeyFrame kf2 = new KeyFrame(Duration.millis(1), e -> {
                         hBox.setBackground(new Background(new BackgroundFill(Color.RED,
                                CornerRadii.EMPTY,
                                Insets.EMPTY)));
                        currentState = 2;
                        text.set("Wait to become green");
                    });

                    final KeyFrame kf3 = new KeyFrame(Duration.millis(5000), e -> {
                       hBox.setBackground(new Background(new BackgroundFill(Color.GREEN,
                                CornerRadii.EMPTY,
                                Insets.EMPTY)));
                        currentState = 3;
                        text.set("Click");
                        start.set(System.currentTimeMillis());
                    });

                    final Timeline timeline = new Timeline(kf1, kf2, kf3);
                    Platform.runLater(timeline::play);
                } else  if (currentState == 2) {
                    hBox.setBackground(new Background(new BackgroundFill(Color.BLUE,
                            CornerRadii.EMPTY,
                            Insets.EMPTY)));
                    text.set("Too soon, click to try again!");
                } else if(currentState == 3) {
                     counter.set(counter.get()+1);
                    long end = System.currentTimeMillis();
                    score.set(end - start.get());
                    System.out.println("Score:"+counter.get());
                    if (counter.get() == 5) {
                        bottomBtnBox.setVisible(true);
                    } else {
                        text.set("You replied in " + score.get() + " ms, click to try again");
                        hBox.setBackground(new Background(new BackgroundFill(Color.BLUE,
                                CornerRadii.EMPTY,
                                Insets.EMPTY)));
                        currentState = 1;
                    }

                }
            }
        });
        primaryStage.setScene(new Scene(root, 400, 200));
    }
}
