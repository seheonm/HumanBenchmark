/* Marina Seheon CS351L Project 2
This is the main class, it is in charge of starting the games
and getting the user's name input.
 */

package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


/**
 * Main class of the application
 */
public class Main extends Application {
    private  String userName;
    @Override
    public void start(Stage primaryStage) throws Exception {
        getName(primaryStage);
        if(null==userName || userName.trim().isEmpty())
            return;
        Controller controller = new Controller(userName);
      new HomeScreen(controller,primaryStage);
    }


    private void getName(Stage parentStage) {
        String name="";
        Stage dialog = new Stage();
        dialog.setTitle("Login Details");
        GridPane gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);

        Label label = new Label("Enter Your Name: ");
        TextField userNameField=new TextField();
        Button submitButton = new Button("Get Started!");
        gridPane.add(label,0,0);
        gridPane.add(userNameField,1,0);
        gridPane.add(submitButton,1,1);

        dialog.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                validateUserName(userNameField,dialog);
            }
        });
        submitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                validateUserName(userNameField,dialog);
            }
        });
        dialog.setScene(new Scene(gridPane, 400, 100));
        dialog.initOwner(parentStage);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.showAndWait();

    }

    private void validateUserName(TextField userNameField,Stage dialog) {
        userName=userNameField.getText();
        if(null!=userName && !userName.trim().isEmpty()){
            userName=userName.trim();
            dialog.close();
        }else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Invalid name");
            alert.showAndWait();
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}
