package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class HomeScreen {
    private final Stage primaryStage;
    private final Controller controller;

    public HomeScreen(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller=controller;
        showHomeScreen();
    }

    private void showHomeScreen() {
        GridPane root = new GridPane();
        root.setMinSize(400, 200);
        root.setPadding(new Insets(30, 10, 10, 10));
        root.setVgap(20);
        root.setHgap(20);
        root.setAlignment(Pos.TOP_CENTER);

        Button b1 = new Button("Reaction Time");
        b1.setPrefSize(150,100);
        b1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playReactionTime();
            }
        });
        root.add(b1, 0, 0);

        Button b2 = new Button("Sequence Memory");
        b2.setPrefSize(150,100);
        b2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playSequenceMemory();
            }
        });


        root.add(b2, 1, 0);
        Button b3 = new Button("Aim Trainer");
        b3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playAimTrainerGame();
            }
        });
        b3.setPrefSize(150,100);

        root.add(b3, 2, 0);

        Button b4 = new Button("Number Memory");
        b4.setPrefSize(150,100);
        b4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playNumberMemoryGame();
            }
        });
        root.add(b4, 0, 1);
        Button b5 = new Button("Verbal Memory");
        b5.setPrefSize(150,100);
        b5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playVerbalMemoryGame();
            }
        });
        root.add(b5, 1, 1);


        Button b6 = new Button("Chimp Test");
        b6.setPrefSize(150,100);
        b6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playChimpTestGame();
            }
        });
        root.add(b6, 2, 1);

        Button b7 = new Button("Visual Memory");
        b7.setPrefSize(150,100);
        b7.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playVisualMemoryGame();
            }
        });

        root.add(b7, 0, 2);

        Button b8 = new Button("Typing");
        b8.setPrefSize(150,100);
        b8.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playTypingGame();
            }
        });
        root.add(b8, 1, 2);

        Button b9 = new Button("Number");
        b9.setPrefSize(150,100);
        b9.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                playNumberGame();
            }
        });
        root.add(b9, 2, 2);

        primaryStage.setTitle("Human Benchmark");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }


    private void playReactionTime(){
        new ReactionTimerGame(this.controller,primaryStage);
    }
    private void playSequenceMemory(){
        new SequenceMemoryGame(this.controller,primaryStage);
    }
    private void playAimTrainerGame(){
        new AimTrainerGame(this.controller,primaryStage);
    }
    private void playTypingGame(){
        new TypingGame(this.controller,primaryStage);
    }
    private void playNumberMemoryGame(){
        new NumberMemoryGame(this.controller,primaryStage);
    }
    private void playVerbalMemoryGame(){
        new VerbalMemoryGame(this.controller,primaryStage);
    }
    private void playVisualMemoryGame(){
        new VisualMemoryGame(this.controller,primaryStage);
    }
    private  void playChimpTestGame(){new ChimpTestGame(this.controller,primaryStage);}
    private void playNumberGame() {new NumberGame(this.controller,primaryStage);}


}
