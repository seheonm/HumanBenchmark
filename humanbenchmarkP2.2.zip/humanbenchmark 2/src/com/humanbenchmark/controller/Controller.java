package com.humanbenchmark.controller;

import com.humanbenchmark.model.User;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Controller {
    private String userName;
    private final List<User> userList;
    private User currentUser;
    private  boolean isUserExist=false;

    public Controller(String userName) {
        this.userName = userName;
        userList=new ArrayList<>();
        loadCsv();
        for (User u:userList ) {
            if(null!=u && u.getName().equals(userName)){
                currentUser=u;
                isUserExist=true;
                break;
            }
        }
        if(currentUser==null) {
            currentUser = new User();
            currentUser.setName(userName);
        }
    }

    /**
     * This loads the CSV file and uses the username to save the
     * scores of the players.
     */
    private void loadCsv() {
        File file = new File("resources/scores.csv");
        Scanner sc = null;
        try {
            sc = new Scanner(file);
            sc.nextLine();
            while (sc.hasNext()) {
                String line = sc.nextLine();
                if (null != line && !line.trim().isEmpty()) {
                    line = line.trim();
                    String[] parts = line.split(",");
                    if (null != parts && parts.length == 9) {
                        try {
                            User user = new User();
                            user.setName(parts[0]);
                            user.setReactionTime(Long.valueOf(parts[1]));
                            user.setSequenceMemory(Long.valueOf(parts[2]));
                            user.setAimTrainer(Long.valueOf(parts[3]));
                            user.setChimpTest(Long.valueOf(parts[4]));
                            user.setVisualMemory(Long.valueOf(parts[5]));
                            user.setTyping(Long.valueOf(parts[6]));
                            user.setNumberMemory(Long.valueOf(parts[7]));
                            user.setVerbalMemory(Long.valueOf(parts[8]));

                        }catch (NumberFormatException nfe){
                            System.out.println(nfe.getMessage());
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    /**
     * This loads the CSV file and uses the username to save the
     * scores of the players.
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the user name.
     * @param userName is a string.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * This updates the reaction time when the user saves
     * tehri score more than once.
     * @param score is a long.
     */
    public void updateReactionTime(long score){
           this.currentUser.setReactionTime(score);
           saveCSV();
    }

    /**
     * This saves the CSV file with the username and the different games.
     */
    private void saveCSV() {
        File file = new File("resources/scores.csv");
        BufferedWriter bw=null;
        try {
            bw=new BufferedWriter(new FileWriter(file));
            bw.write("name, reaction_time, sequence_memory, aim_trainer, " +
                    "chimp_test, visual_memory,typing, number_memory, " +
                    "verbal_memory\n");
            for (User user:userList) {
                bw.write(user.toString());
                bw.newLine();
            }
            if(!isUserExist){
                bw.write(currentUser.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(null!=bw){
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /**
     * Updates the score for the Sequence Memory Game.
     * @param score is a long.
     */
    public void updateSequenceMemoryTime(long score) {
        this.currentUser.setSequenceMemory(score);
        saveCSV();
    }

    /**
     * Updates the score for the Aim Trainer Game.
     * @param score is a long.
     */
    public void updateAimTrainerTime(long score) {
        this.currentUser.setAimTrainer(score);
        saveCSV();
    }

    /**
     * Updates the score for the Typing Game.
     * @param score is a long.
     */
    public void updateTypingTime(long score) {
        this.currentUser.setTyping(score);
        saveCSV();
    }

    /**
     * Updates the score for the Number Memory Game.
     * @param score is a long.
     */
    public void updateNumberMemoryScore(long score) {
        this.currentUser.setNumberMemory(score);
        saveCSV();
    }

    /**
     * Updates the score for the Visual Memory Game.
     * @param score is a long.
     */
    public void updateVisualMemoryScore(long score) {
        this.currentUser.setVisualMemory(score);
        saveCSV();
    }

    /**
     * Updates the score for the Verbal Memory Game.
     * @param score is a long.
     */
    public void updateVerbalMemoryScore(int score) {
        this.currentUser.setVerbalMemory(score);
        saveCSV();
    }

    /**
     * Updates the score for the Chimp Test Game.
     * @param score is a long.
     */
    public void updateChimpTestGameScore(int score) {
        this.currentUser.setChimpTest(score);
        saveCSV();
    }

    /**
     * Updates the score for the Number Game.
     * @param i is an int.
     */
    public void updateVNumberScore(int i) {
    }
}
