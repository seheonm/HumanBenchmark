package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ChimpTestGame {
    private final Controller controller;
    private final Stage primaryStage;
    private final int currentState = 1;
    private final List<String> words = new ArrayList<>();

    public ChimpTestGame(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller = controller;
        showChimpTestGameScreen();
    }

    /**
     * Sets the Screen for the Chimp Test Game.
     */
    private void showChimpTestGameScreen() {
        BorderPane root = new BorderPane();
        Button backBtn = new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                new HomeScreen(controller, primaryStage);
            }
        });
        SimpleIntegerProperty lives = new SimpleIntegerProperty(3);
        SimpleIntegerProperty level = new SimpleIntegerProperty(1);
        SimpleIntegerProperty numberOfButtons = new SimpleIntegerProperty(4);

        Label livesLabel = new Label("Lives " + lives.get());
        Label levelLabel = new Label("Level " + level.get());

        GridPane topBox = new GridPane();
        topBox.setHgap(20);
        topBox.add(backBtn, 0, 0);
        topBox.add(levelLabel, 1, 0);
        topBox.add(livesLabel, 2, 0);

        GridPane centerBox = new GridPane();
        centerBox.setHgap(20);
        centerBox.setVgap(20);
        HBox bottomBtnBox = new HBox();
        List<KeyValue> keyValues = new ArrayList<>();
        addButtons(centerBox, bottomBtnBox, root, lives, level, livesLabel,
                levelLabel, numberOfButtons, keyValues);
        Button saveScoreBtn = new Button("Save Score");
        saveScoreBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                controller.updateChimpTestGameScore(level.get());
                new ChimpTestGame(ChimpTestGame.this.controller, primaryStage);
            }
        });
        Button tryAgainBtn = new Button("Try Again");

        tryAgainBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                new ChimpTestGame(ChimpTestGame.this.controller, primaryStage);
            }
        });
        bottomBtnBox.getChildren().addAll(saveScoreBtn, tryAgainBtn);
        bottomBtnBox.setVisible(false);

        root.setTop(topBox);
        Insets insets = new Insets(20);
        root.setPadding(insets);
        centerBox.setPadding(insets);
        root.setCenter(centerBox);
        root.setBottom(bottomBtnBox);
        primaryStage.setScene(new Scene(root, 800, 800));

    }

    /**
     * This adds the rectangles you need to click.
     * @param centerBox is type Grid Pane.
     * @param bottomBtnBox is type HBox.
     * @param root is type BorderPane.
     * @param lives is type SimpleIntegerProperty.
     * @param level is type SimpleIntegerProperty.
     * @param livesLabel is type Label.
     * @param levelLabel is type Label.
     * @param numberOfButtons is type SimpleIntegerProperty.
     * @param keyValues is type List</KeyValue>.
     */
    private void addButtons(GridPane centerBox, HBox bottomBtnBox,
                            BorderPane root, SimpleIntegerProperty lives,
                            SimpleIntegerProperty level, Label livesLabel,
                            Label levelLabel,
                            SimpleIntegerProperty numberOfButtons,
                            List<KeyValue> keyValues) {
        Random r = new Random();
        SimpleIntegerProperty counter = new SimpleIntegerProperty(0);

        for (int i = 0; i < numberOfButtons.get(); i++) {
            int row = -1;
            int col = -1;
            boolean isExist = false;
            do {

                row = r.nextInt(15);
                col = r.nextInt(15);
                for (KeyValue keyValue : keyValues) {
                    if (keyValue.col == col && keyValue.row == row) {
                        isExist = true;
                        break;
                    }
                }
            } while (isExist);
            KeyValue keyValue = new KeyValue();
            keyValue.row = row;
            keyValue.col = col;
            keyValues.add(keyValue);
            Button button = new Button((i + 1) + "");
            button.setBackground(new Background(new BackgroundFill(Color.BLUE,
                    CornerRadii.EMPTY,
                    Insets.EMPTY)));
            button.setPrefSize(50, 50);
            button.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            int val = Integer.valueOf(button.getText());
                            if (val - 1 == counter.get()) {
                                centerBox.getChildren().remove(button);
                                if (level.get() != 1) {
                                    centerBox.setBackground(new Background
                                            (new BackgroundFill(Color.BLUE,
                                            CornerRadii.EMPTY,
                                            Insets.EMPTY)));
                                    for (Node node : centerBox.getChildren()) {
                                        if (node instanceof Button) {
                                            ((Button) node).setStyle
                                                    ("-fx-text-fill: white");
                                            ((Button) node).setBackground
                                                    (new Background(new
                                                            BackgroundFill(Color.WHITE,
                                                    CornerRadii.EMPTY,
                                                    Insets.EMPTY)));

                                        }
                                    }
                                }
                                counter.set(counter.get() + 1);
                            } else {
                                lives.set(lives.get() - 1);
                                livesLabel.setText("Lives:" + lives.get());
                                level.set(level.get() + 1);
                                levelLabel.setText("Level:" + level.get());
                            }
                            if (lives.get() == 0) {
                                root.setCenter(livesLabel);
                                bottomBtnBox.setVisible(true);
                            } else {
                                if (centerBox.getChildren().isEmpty()) {
                                    level.set(level.get() + 1);
                                    levelLabel.setText("Level:" + level.get());
                                    numberOfButtons.set(numberOfButtons.get() + 1);
                                    keyValues.clear();
                                    addButtons(centerBox, bottomBtnBox, root,
                                            lives, level, livesLabel,
                                            levelLabel, numberOfButtons,
                                            keyValues);
                                }
                            }

                        }
                    });
                }
            });
            centerBox.add(button, col, row);
        }
    }
}
