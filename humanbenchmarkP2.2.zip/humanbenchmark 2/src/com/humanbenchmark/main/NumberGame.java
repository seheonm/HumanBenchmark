package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Random;

public class NumberGame {
    private final Controller controller;
    private final Stage primaryStage;

    public NumberGame(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller = controller;
        showNumberGameScreen();
    }

    /**
     * Sets the screen for the Number Game.
     */
    private void showNumberGameScreen() {
        BorderPane root = new BorderPane();
        Button backBtn = new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new HomeScreen(controller, primaryStage);
            }
        });


        GridPane topBox = new GridPane();
        topBox.setHgap(20);
        topBox.add(backBtn, 0, 0);
        HBox bottomBtnBox = new HBox();

        GridPane centerBox = new GridPane();
        centerBox.setHgap(20);
        centerBox.setVgap(20);
        SimpleIntegerProperty counter= new SimpleIntegerProperty();
        VBox vBox = new VBox(15);
        SimpleLongProperty number = new SimpleLongProperty();
        Random r = new Random(System.currentTimeMillis());
        long num=r.nextLong();
        number.set(num);
        Label infoLabel = new Label("Type the given number");
        Label numLabel = new Label(""+num);
        TextField field= new TextField();
        Button submit = new Button("Submit");
        submit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        String val=field.getText();
                        if(null!=val && !val.trim().isEmpty()){
                            if(val.equals(num+"")){
                                field.clear();
                                number.set(r.nextInt());
                                numLabel.setText(number.get()+"");
                                counter.set(counter.get()+1);
                            }else{
                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                alert.setContentText
                                        ("Entered number is incorrect.");
                                alert.setTitle("Error");
                                Label label=new Label
                                        ("Level:"+counter.get());
                                root.setCenter(label);
                                bottomBtnBox.setVisible(true);
                            }
                        }
                    }
                });

            }
        });
        vBox.getChildren().addAll(infoLabel,numLabel,field,submit);
        centerBox.add(vBox,2,1);
        Button saveScoreBtn = new Button("Save Score");
        saveScoreBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                controller.updateVNumberScore(counter.get());
                new NumberGame(NumberGame.this.controller, primaryStage);
            }
        });
        Button tryAgainBtn = new Button("Try Again");

        tryAgainBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new NumberGame(NumberGame.this.controller, primaryStage);
            }
        });
        bottomBtnBox.getChildren().addAll(saveScoreBtn, tryAgainBtn);
        bottomBtnBox.setVisible(false);

        root.setTop(topBox);
        Insets insets = new Insets(20);
        root.setPadding(insets);
        centerBox.setPadding(insets);
        root.setCenter(centerBox);
        root.setBottom(bottomBtnBox);
        primaryStage.setScene(new Scene(root, 600, 400));
    }
}
