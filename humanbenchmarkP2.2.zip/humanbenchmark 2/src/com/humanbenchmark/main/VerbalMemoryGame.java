package com.humanbenchmark.main;

import com.humanbenchmark.controller.Controller;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class VerbalMemoryGame {
    private final Controller controller;
    private final Stage primaryStage;
    private final int currentState = 1;
    private final List<String> words = new ArrayList<>();

    public VerbalMemoryGame(Controller controller, Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.controller = controller;
        loadDictionary();
        showVerbalMemoryGameScreen();
    }

    /**
     * Loads the dictionary given to show each of the words.
     */
    private void loadDictionary() {
        try {
            Scanner sc = new Scanner(new File("resources/dictionary.txt"));
            while (sc.hasNext()) {
                String line = sc.nextLine();
                if (null != line && !line.trim().isEmpty()) {
                    words.add(line.trim());
                }
            }
            sc.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets the screen for the Verbal Memory Game.
     */
    private void showVerbalMemoryGameScreen() {
        BorderPane root = new BorderPane();
        SimpleLongProperty level = new SimpleLongProperty();
        Button backBtn = new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new HomeScreen(controller, primaryStage);
            }
        });
        SimpleIntegerProperty lives = new SimpleIntegerProperty(3);
        SimpleIntegerProperty score = new SimpleIntegerProperty(0);
        Label livesLabel = new Label("Lives " + lives.get());
        Label scoreLabel = new Label("Score " + score.get());
        GridPane topBox = new GridPane();
        topBox.setHgap(20);
        topBox.add(backBtn, 0, 0);
        topBox.add(livesLabel, 1, 0);
        topBox.add(scoreLabel, 2, 0);

        VBox centerBox = new VBox(40);
        List<String> previousWords = new ArrayList<>();

        SimpleStringProperty word = new SimpleStringProperty();
        Random r = new Random();
        int len = r.nextInt(words.size());
        word.set(words.get(len));

        Button seenBtn = new Button("Seen");
        Button newBtn = new Button("New");
        Label wordLabel = new Label(word.get());

        HBox buttonBox = new HBox(20);
        buttonBox.getChildren().addAll(seenBtn, newBtn);
        centerBox.getChildren().addAll(wordLabel, buttonBox);


        HBox bottomBtnBox = new HBox();
        Button saveScoreBtn = new Button("Save Score");
        saveScoreBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                controller.updateVerbalMemoryScore(score.get());
                new VerbalMemoryGame(VerbalMemoryGame.this.controller,
                        primaryStage);
            }
        });
        Button tryAgainBtn = new Button("Try Again");

        tryAgainBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new VerbalMemoryGame(VerbalMemoryGame.this.controller,
                        primaryStage);
            }
        });
        bottomBtnBox.getChildren().addAll(saveScoreBtn, tryAgainBtn);
        bottomBtnBox.setVisible(false);

        root.setTop(topBox);
        Insets insets = new Insets(20);
        root.setPadding(insets);
        centerBox.setPadding(insets);
        root.setCenter(centerBox);
        root.setBottom(bottomBtnBox);
        primaryStage.setScene(new Scene(root, 400, 200));

        seenBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        if (previousWords.contains(word.get())) {
                            score.set(score.get() + 1);
                            int len = r.nextInt(words.size());
                            word.set(words.get(len));
                        } else {
                            lives.set(lives.get() - 1);
                            if (lives.get() == 0) {
                                bottomBtnBox.setVisible(true);
                            } else {
                                int len = r.nextInt(words.size());
                                word.set(words.get(len));
                            }
                        }
                        livesLabel.setText("Lives:"+lives.get());
                        scoreLabel.setText("Score:"+score.get());
                        wordLabel.setText(word.get());
                    }
                });
            }
        });

        newBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        if (!previousWords.contains(word.get())) {
                            score.set(score.get() + 1);
                            scoreLabel.setText("Score:"+score.get());
                            int len = r.nextInt(words.size());
                            word.set(words.get(len));
                        } else {
                            lives.set(lives.get() - 1);
                            if (lives.get() == 0) {
                                bottomBtnBox.setVisible(true);
                            } else {
                                int len = r.nextInt(words.size());
                                word.set(words.get(len));

                            }
                        }
                        livesLabel.setText("Lives:"+lives.get());
                        scoreLabel.setText("Score:"+score.get());
                        wordLabel.setText(word.get());
                    }
                });
            }
        });

    }
}
