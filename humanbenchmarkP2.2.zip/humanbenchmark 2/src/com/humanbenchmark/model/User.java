package com.humanbenchmark.model;

public class User {
    private String name;
    private long reactionTime, sequenceMemory, aimTrainer, chimpTest,
            visualMemory, typing, numberMemory, verbalMemory;

    /**
     * Gets the name.
     * @return type String.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     * @param name is type String
     */
    public void setName(String name) {
        this.name = name;
    }


    /**
     * Sets the reaction time score.
     * @param reactionTime is type long.
     */
    public void setReactionTime(long reactionTime) {

        this.reactionTime = reactionTime;
    }

    /**
     * Sets the sequence memory score.
     * @param sequenceMemory is type long.
     */
    public void setSequenceMemory(long sequenceMemory) {
        this.sequenceMemory = sequenceMemory;
    }

    /**
     * Sets the aim trainer score.
     * @param aimTrainer is type long.
     */
    public void setAimTrainer(long aimTrainer) {
        this.aimTrainer = aimTrainer;
    }

    /**
     * Sets the chimp test score.
     * @param chimpTest is type long.
     */
    public void setChimpTest(long chimpTest) {
        this.chimpTest = chimpTest;
    }

    /**
     * Sets the visual memory score.
     * @param visualMemory is type long.
     */
    public void setVisualMemory(long visualMemory) {
        this.visualMemory = visualMemory;
    }

    /**
     * Sets the typing score.
     * @param typing is type long.
     */
    public void setTyping(long typing) {
        this.typing = typing;
    }

    /**
     * Sets the number memory score.
     * @param numberMemory is type long.
     */
    public void setNumberMemory(long numberMemory) {
        this.numberMemory = numberMemory;
    }

    /**
     * Sets the verbal memory score.
     * @param verbalMemory is type long.
     */
    public void setVerbalMemory(long verbalMemory) {
        this.verbalMemory = verbalMemory;
    }

    @Override
    public String toString() {
        return name + "," + reactionTime + "," + sequenceMemory + "," +
                aimTrainer +  "," + chimpTest +  "," + visualMemory +
                "," + typing +    "," + numberMemory +  "," +
                verbalMemory;
    }
}
